from flask import Flask, render_template, request, jsonify
import pandas as pd
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from fuzzywuzzy import process

# Download NLTK dependencies
nltk.download('punkt')
nltk.download('stopwords')

# Load CSV file
df = pd.read_csv("trouble.csv")

# Strip spaces from column names to prevent mismatches
df.columns = df.columns.str.strip()

# Preprocess stopwords
stop_words = set(stopwords.words('english'))

def preprocess(text):
    """Tokenizes and cleans text."""
    words = word_tokenize(str(text).lower())
    words = [word for word in words if word.isalnum() and word not in stop_words]
    return " ".join(words)

# Create a dictionary mapping 'Issue' to row values
device_dict = {str(row['Issue']).lower(): row.to_dict() for _, row in df.iterrows()}

# Mapping of possible query keywords to DataFrame columns
column_mapping = {
    "issue": "Issue",
    "device issue caused": "Device Issue Caused",
    "value": "Value",
    "network impact": "Network Impact",
    "impact value": "Impact Value",
    "troubleshooting": "Does troubleshooting solve this"
}

def get_closest_match(user_input, choices):
    """Finds the closest matching issue using fuzzy matching."""
    match, score = process.extractOne(user_input, choices)
    return match if score > 80 else None  # 80 is the confidence threshold

def get_response(user_input):
    """Processes user query and returns the appropriate response."""
    user_input = user_input.lower().strip()

    # Debugging: Print available issues
    print("Available Issues in Dictionary:", list(device_dict.keys()))

    # Get closest matching issue
    issue_match = get_closest_match(user_input, device_dict.keys())

    if issue_match:
        issue_data = device_dict[issue_match]
        
        # Check if user asks for a specific column
        for word in user_input.split():
            if word in column_mapping:
                column_name = column_mapping[word]
                return f"{column_name}: {issue_data.get(column_name, 'Information not available')}"
        
        # Return full issue details if no specific column is requested
        return "\n".join([f"{col}: {issue_data[col]}" for col in df.columns if col != "Issue"])

    return "Sorry, I couldn't find relevant information."

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_query = request.json.get("query", "")
    response_text = get_response(user_query)
    return jsonify({"response": response_text})

if __name__ == '__main__':
    app.run(debug=True)
