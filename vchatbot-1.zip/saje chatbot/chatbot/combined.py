from flask import Flask, render_template, request, jsonify
import pandas as pd
import nltk
import re
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from fuzzywuzzy import process

# Download NLTK dependencies
nltk.download('punkt')
nltk.download('stopwords')

# Load CSV files
df_trouble = pd.read_csv("trouble.csv")
df_customer = pd.read_csv("Customer_1.csv")

# Strip spaces from column names
df_trouble.columns = df_trouble.columns.str.strip()
df_customer.columns = df_customer.columns.str.strip()

# Preprocess stopwords
stop_words = set(stopwords.words('english'))

def preprocess(text):
    words = word_tokenize(str(text).lower())
    words = [word for word in words if word.isalnum() and word not in stop_words]
    return " ".join(words)

# Create dictionaries for issue and device data
device_issues = {str(row['Issue']).lower(): row.to_dict() for _, row in df_trouble.iterrows()}
device_status = {str(row['Device ID']).lower(): row.to_dict() for _, row in df_customer.iterrows()}

# Column mappings for both datasets
trouble_column_mapping = {
    "issue": "Issue",
    "device issue caused": "Device Issue Caused",
    "value": "Value",
    "network impact": "Network Impact",
    "impact value": "Impact Value",
    "troubleshooting": "Does troubleshooting solve this"
}

customer_column_mapping = {
    "cpu": "CPU Usage (%)",
    "memory": "Memory Usage (%)",
    "battery": "Battery Health (%)",
    "disk": "Disk Usage (%)",
    "latency": "Network Latency (ms)",
    "temperature": "Temperature (°C)",
    "errors": "Errors Detected",
    "security": "Security Status",
    "screen time": "Screen Time (hrs/day)",
    "charge cycles": "Charge Cycles",
    "app crashes": "App Crashes (last 7 days)",
    "os update": "Last OS Update",
    "wifi": "WiFi Signal Strength (dBm)",
    "bluetooth": "Bluetooth Connectivity Issues (past week)",
    "system errors": "System Errors (last 30 days)",
    "restarts": "Device Restart Count (last month)",
    "malware": "Malware Detection",
    "battery drain": "Battery Drain Rate (%/hr)",
    "sensor failures": "Sensor Failures"
}

def get_closest_match(user_input, choices):
    match, score = process.extractOne(user_input, choices)
    return match if score > 80 else None

def get_response(user_input):
    user_input = user_input.lower().strip()
    words = user_input.split()

    # Check if input contains a device ID in the format C1_D<number>
    device_id_match = re.search(r'c1_d\d+', user_input)
    if device_id_match:
        device_id = device_id_match.group()  # Extract device ID

        # Ensure the device ID exists in the customer dataset
        if device_id in device_status:
            # Check if the user is asking for specific information
            for word in words:
                if word in customer_column_mapping:
                    column_name = customer_column_mapping[word]
                    return f"{column_name}: {device_status[device_id].get(column_name, 'Information not available')}"

            # If no specific column requested, return all device details
            return "\n".join([f"{col}: {device_status[device_id][col]}" for col in df_customer.columns if col != "Device ID"])
        
        return "Device ID not found in the database."

    # If no device ID, check for issues in trouble.csv
    issue_match = get_closest_match(user_input, device_issues.keys())
    if issue_match:
        issue_data = device_issues[issue_match]
        for word in words:
            if word in trouble_column_mapping:
                column_name = trouble_column_mapping[word]
                return f"{column_name}: {issue_data.get(column_name, 'Information not available')}"

        return "\n".join([f"{col}: {issue_data[col]}" for col in df_trouble.columns if col != "Issue"])

    return "Sorry, I couldn't find relevant information."

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_query = request.json.get("query", "")
    response_text = get_response(user_query)
    return jsonify({"response": response_text})

if __name__ == '__main__':
    app.run(debug=True)
