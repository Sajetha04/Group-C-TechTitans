from flask import Flask, render_template, request, jsonify
import pandas as pd
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords

# Download NLTK dependencies
nltk.download('punkt')
nltk.download('stopwords')

# Load CSV file
df = pd.read_csv("Customer_1.csv")

# Preprocess stopwords
stop_words = set(stopwords.words('english'))

def preprocess(text):
    words = word_tokenize(str(text).lower())
    words = [word for word in words if word.isalnum() and word not in stop_words]
    return " ".join(words)

# Create a dictionary mapping Device ID to row values
device_dict = {str(row['Device ID']).lower(): row.to_dict() for _, row in df.iterrows()}

# Mapping of possible query keywords to DataFrame columns
column_mapping = {
    "cpu": "CPU Usage (%)",
    "memory": "Memory Usage (%)",
    "battery": "Battery Health (%)",
    "disk": "Disk Usage (%)",
    "latency": "Network Latency (ms)",
    "temperature": "Temperature (Â°C)",
    "errors": "Errors Detected",
    "security": "Security Status",
    "screen time": "Screen Time (hrs/day)",
    "charge cycles": "Charge Cycles",
    "app crashes": "App Crashes (last 7 days)",
    "os update": "Last OS Update",
    "wifi": "WiFi Signal Strength (dBm)",
    "bluetooth": "Bluetooth Connectivity Issues (past week)",
    "system errors": "System Errors (last 30 days)",
    "restarts": "Device Restart Count (last month)",
    "malware": "Malware Detection",
    "battery drain": "Battery Drain Rate (%/hr)",
    "sensor failures": "Sensor Failures"
}

def get_response(user_input):
    user_input = user_input.lower().strip()
    words = user_input.split()

    device_id = None
    column_name = None

    # Identify the device ID in the input
    for word in words:
        if word in device_dict:
            device_id = word
            break

    # Identify the query type (battery, CPU, etc.)
    for word in words:
        if word in column_mapping:
            column_name = column_mapping[word]
            break

    if device_id:
        if column_name:
            return f"{column_name}: {device_dict[device_id].get(column_name, 'Information not available')}"
        else:
            return "\n".join([f"{col}: {device_dict[device_id][col]}" for col in df.columns if col != "Device ID"])

    return "Sorry, I couldn't find relevant information."

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_query = request.json.get("query", "")
    response_text = get_response(user_query)
    return jsonify({"response": response_text})

if __name__ == '__main__':
    app.run(debug=True)
